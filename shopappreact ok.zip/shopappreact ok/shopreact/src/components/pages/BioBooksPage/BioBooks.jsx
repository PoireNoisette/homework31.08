
import './BioBooks.css'
import productList from './products.json';

const cart = [
    {
        id: 1,
        title: "Summer book",
        price: 109.95,
        image: "https://www.elefant.ro/cdn-cgi/image/fit=scale-down,format=auto,width=1000/https://cdn.elefant.ro/is/product-images/cartero/53c5f4ff/dbfc/434f/896e/5e7732839e8d/53c5f4ff-dbfc-434f-896e-5e7732839e8d_1.jpg",
        pieces: 3,
    },
]

const BioBooksPage = (props) => {
    console.log(productList)
    const addToCart = function (addedProduct) {
        console.log("Added to cart product =", addedProduct)
        const existProduct = cart.find((cartProduct) => {
            return cartProduct.id === addedProduct.id;
        })
        if (existProduct) {
            existProduct.pieces++;
        } else {
            addedProduct.pieces = 1;
            cart.push(addedProduct);
        }

        console.log('Current cart = ', cart)
    }
    return (
        <>
            <div className="product-list">
                {productList.map((product) => {
                    return (
                        <div className='product'>
                            <h1>{product.title}</h1>
                            <img src={product.image}></img>
                            <p>{product.price} </p>
                            <div className='btn-container' onClick={
                                function () {
                                    console.log('ai dat clic')
                                }
                            }>
                                <button className='btn' onClick={(_event) => {
                                    addToCart(product);
                                }}>Add to Cart</button>
                            </div>
                        </div>
                    )
                })}
            </div>
        </>
    )
}



export default BioBooksPage;
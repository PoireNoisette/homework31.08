import './Layout.css';
import { Link } from "react-router-dom";

function Layout(props) {
    return (
        <div className='layout'>
            <header>
                <h1>Bio-books Shop</h1>
                <nav>
                    <ul>
                        <li>
                            <Link to='/booklist'>BioBooksPage</Link>
                            {/* <a href="#">BioBooksPage</a>*/}
                        </li>
                        <li>
                            <Link to='/shopcart'>ShoppingCart ({props.itemsCount}) items</Link>
                            {/* <a href="#">ShoppingCart</a>*/}
                        </li>
                    </ul>
                </nav>
            </header>
            <main id="app-main-content">
                {props.children}
            </main>
        </div >
    )
}

export default Layout